var s=class{constructor(){this.fields="",this.orderBy="",this.searchQuery="",this.pageSize=30,this.skip=0,this.name="",this.totalCount=0,this.metaTags=""}};export{s as a};
