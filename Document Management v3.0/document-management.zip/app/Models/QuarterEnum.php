<?php

namespace App\Models;

enum QuarterEnum: int
{
    case Quarter1 = 0;
    case Quarter2 = 1;
    case Quarter3 = 2;
    case Quarter4 = 3;
}
