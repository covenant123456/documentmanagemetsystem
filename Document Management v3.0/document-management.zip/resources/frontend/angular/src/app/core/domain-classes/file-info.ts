export interface FileInfo {
  fileName: string;
  id: string;
}
