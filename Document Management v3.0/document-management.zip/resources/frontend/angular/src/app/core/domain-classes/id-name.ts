export class IdName {
  id: number;
  name: string;
}
