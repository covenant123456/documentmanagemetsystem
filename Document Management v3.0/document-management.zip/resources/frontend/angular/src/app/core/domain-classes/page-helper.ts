export class PageHelper {
  id?: string;
  code?: string;
  name?: string;
  description?: string;
}
