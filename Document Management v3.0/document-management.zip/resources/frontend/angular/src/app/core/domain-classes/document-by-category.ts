export class DocumentByCategory {
    categoryName: string;
    documentCount: number;
}
