import { ResourceParameter } from './resource-parameter';

export class LoginAuditResource extends ResourceParameter {
    id?: string = '';
    userName?: string = '';
}