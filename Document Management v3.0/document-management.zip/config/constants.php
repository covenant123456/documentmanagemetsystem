<?php

return [
    'APP_VERSION' => '3.0.0',
];
